#!/bin/bash

echo -
echo Starting RabbitMQ Application...
sudo docker-compose up --build -d
