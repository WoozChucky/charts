#!/bin/bash

echo Starting All Applications...

cd rabbit/
sudo sh start.sh
cd ..

cd nginx/
sudo sh start.sh
cd ..
