# Carris Containers Quality 

Carris Containers Quality - Docker Compose Stack


### Create a Virtal Machime
* [Azure Virtual Machines](https://portal.azure.com/#blade/HubsExtension/BrowseResourceBlade/resourceType/Microsoft.Compute%2FVirtualMachines)

### Instance Type 
Operating System: Linux (Ubuntu 18.04 LTS)<br>
Location: North Europe<br>
Resource Group: rg-p_axi-ql-sc-app<br>
Size: Standard B4ms (4 vcpus, 16 GiB memory)<br>

### Allow Ports
SSH: 22 (Only my Host)<br>
HTTP: 80 (All Trafic)<br>
HTTPS: 443 (All Trafic)<br>
POSTGRES: 5432 (All Trafic)<br>
REDIS: 6379 (All Trafic)<br>
RABBIT MQ: 15672 (All Trafic)<br>
MONGO DB: 27071 (All Trafic)<br>


## Run After Install

### Update and Upgrade Packages
```bash
sudo apt-get update
sudo apt-get upgrade -y
```

### Install Git
```bash
sudo apt-get install git -y
```

### Install Docker
```bash
sudo apt-get install docker.io -y
```

### Install Docker-Compose
[Doc - Install Docker Compose](https://docs.docker.com/compose/install/)
```bash
sudo curl -L "https://github.com/docker/compose/releases/download/1.25.4/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose
sudo ln -s /usr/local/bin/docker-compose /usr/bin/docker-compose
```

## Create Git Folder and Clone this Repository
```bash
mkdir git && cd git
git clone https://scgbcarris@dev.azure.com/scgbcarris/SCGB/_git/carris-containers-quality
```

## Run All Containers
```bash
./start_all.sh 
```

## Stop All Containers
```bash
./stop_all.sh 
```




