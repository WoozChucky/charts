#!/bin/bash

echo -
echo Starting NGINX Application...
sudo docker-compose up --build -d
