#!/bin/bash

echo -
echo Stoping Application...
sudo docker-compose down
