#!/bin/bash

echo Stoping All Applications...

cd nginx/
sudo sh stop.sh
cd ..

cd rabbit/
sudo sh stop.sh
cd ..
